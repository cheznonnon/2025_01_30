//
//  AppDelegate.m
//  Nonnon Tools
//
//  Created by のんのん on 2022/11/07.
//

#import "AppDelegate.h"




#include "../../nonnon/neutral/bmp/all.c"
#include "../../nonnon/neutral/curico.c"
#include "../../nonnon/neutral/midi.c"
#include "../../nonnon/neutral/zip.c"


#include "../../nonnon/mac/n_textfield.c"


#include "stub.c"

#include "dotfiles_remover.c"
#include "favorites2html.c"
#include "timestamp.c"




@interface AppDelegate ()

@property (strong) IBOutlet NSWindow *window;

@property (strong) IBOutlet NonnonStub *n_stub;

@property (weak) IBOutlet NSTextField *n_tools_input;
@property (weak) IBOutlet NSButton *n_button_zero_timestamp;
@property (weak) IBOutlet NSButton *n_button_dotfiles_remover;

@end




@implementation AppDelegate


- (IBAction)n_button_method:(id)sender {


	n_posix_char *path = n_mac_nsstring2str( [_n_tools_input stringValue] );

	n_timestamp_directory( path );

	n_string_free( path );

}

- (IBAction)n_button_dotfiles_remover_method:(id)sender {

	n_posix_char *path = n_mac_nsstring2str( [_n_tools_input stringValue] );

	n_mac_tools_dotfiles_remover( path );

	n_string_free( path );

}

- (IBAction)n_button_icon_unpack:(id)sender {

	n_posix_char *path = n_mac_nsstring2str( [_n_tools_input stringValue] );

	if ( n_posix_stat_is_dir( path ) )
	{
		n_curico_multi_pack( path );
	} else {
		n_curico_multi_unpack( path );
	}

	n_string_free( path );

}

- (IBAction)n_button_arcdrop:(id)sender {

	n_posix_char *path = n_mac_nsstring2str( [_n_tools_input stringValue] );

	n_zip_main( path );

	n_string_free( path );

}

- (IBAction)n_button_favorites2html:(id)sender {

	n_posix_char *path = n_mac_nsstring2str( [_n_tools_input stringValue] );
//NSLog( @"%s", path );

	n_favorites2html_main( path );

	n_string_free( path );

}

- (IBAction)n_button_nmidi:(id)sender {

	n_posix_char *path = n_mac_nsstring2str( [_n_tools_input stringValue] );
//NSLog( @"%s", path );

	n_midi_encode( path, n_posix_false );

	n_string_free( path );

}



- (void)NonnonDragAndDrop_dropped:(NSString*)nsstr
{
//NSLog( @"%@", nsstr );

	[_n_tools_input setStringValue:nsstr];

}




- (void)awakeFromNib
{

	_n_stub = [[NonnonStub alloc] init];
	[_n_stub setFrame:[[NSScreen mainScreen] frame]];
	[[_window contentView] addSubview:_n_stub];

	_n_stub.delegate = self;


	[[NSNotificationCenter defaultCenter]
	      addObserver: self
		 selector: @selector( windowWillClose: )
		     name: NSWindowWillCloseNotification
		   object: nil
	];
}

- (void) windowWillClose:(NSNotification *)notification
{
//NSLog( @"closed" );

	NSWindow *window = notification.object;
	if ( window == self.window )
	{
		[NSApp terminate:self];
	}
}
- (void)applicationDidFinishLaunching:(NSNotification *)aNotification {
	// Insert code here to initialize your application
}


- (void)applicationWillTerminate:(NSNotification *)aNotification {
	// Insert code here to tear down your application
}


- (BOOL)applicationSupportsSecureRestorableState:(NSApplication *)app {
	return YES;
}




- (IBAction)n_tools_menu_readme:(id)sender {

	NSString *helpFilePath = [[NSBundle mainBundle] pathForResource:@"nonnon_tools" ofType:@"html"];
	NSURL    *helpFileURL  = [NSURL fileURLWithPath:helpFilePath];

	[[NSWorkspace sharedWorkspace] openURL:helpFileURL];

}


@end
