//
//  main.m
//  Nonnon CatPad
//
//  Created by のんのん on 2022/08/14.
//

#import <Cocoa/Cocoa.h>

int main(int argc, const char * argv[]) {
	@autoreleasepool {
	    // Setup code that might create autoreleased objects goes here.
	}
	return NSApplicationMain(argc, argv);
}
